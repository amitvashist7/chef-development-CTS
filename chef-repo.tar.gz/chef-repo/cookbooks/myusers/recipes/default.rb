#
# Cookbook:: myusers
# Recipe:: default
#
# Copyright:: 2018, The Authors, All Rights Reserved.
# Let's use our user databag. 
#

search("users","platform:centos").each do |user_data|
  user user_data['id'] do 
       comment user_data['comment']
       uid user_data['uid']
       shell user_data['shell']
       home user_data['home']
  end
end

include_recipe "myusers::groups"
