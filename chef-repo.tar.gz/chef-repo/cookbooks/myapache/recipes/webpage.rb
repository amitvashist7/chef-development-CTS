remote_file "#{node['main']['doc_root']}/mario-1.jpg" do
source 'http://www.mariomayhem.com/downloads/wallpapers/7/nsmb_wp7_1280.jpg'
end



template "#{node['main']['doc_root']}/index.html" do 
source 'index.erb'
action :create
variables( 
 :firstname => 'GCP',
 :lastname => 'Cloud',
 :doc_root =>"#{node['main']['doc_root'] }"
)
#notifies :restart, 'service[httpd]', :delayed
end


cookbook_file "#{node['main']['doc_root']}/abc.html" do
 source 'abc.html'
end


