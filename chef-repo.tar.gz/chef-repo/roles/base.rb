name "base"
description "An Base Chef role"
run_list "recipe[mychef-client]"
