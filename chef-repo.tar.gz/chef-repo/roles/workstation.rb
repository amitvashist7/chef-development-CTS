name "workstation"
description "An Workstation Chef role"
run_list "recipe[myusers]","recipe[mychef-client]","recipe[workstation]"
