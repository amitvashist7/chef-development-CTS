name "webserver"
description "An Apache WebServer Chef role"
run_list "recipe[myapache]"
