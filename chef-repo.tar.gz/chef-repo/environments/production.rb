name 'production'
description 'My Prodcution Environment'

cookbook 'myapache', '= 0.4.1'
cookbook 'mychef-client', '= 0.1.3'
cookbook 'workstation', '= 0.2.0'
